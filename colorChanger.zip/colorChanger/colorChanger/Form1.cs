﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace colorChanger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMix_Click(object sender, EventArgs e)
        {
            if (rb1Blue.Checked && rb2Blue.Checked) 
                this.BackColor = Color.Blue;
            else if(rb1Blue.Checked && rb2Yellow.Checked)
                this.BackColor = Color.Green;
            else if(rb1Red.Checked && rb2Blue.Checked)
                this.BackColor = Color.Purple;
            else 
                this.BackColor = Color.Orange;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rb1Red_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1Blue.Checked && rb2Blue.Checked)
                this.BackColor = Color.Blue;
            else if (rb1Blue.Checked && rb2Yellow.Checked)
                this.BackColor = Color.Green;
            else if (rb1Red.Checked && rb2Blue.Checked)
                this.BackColor = Color.Purple;
            else
                this.BackColor = Color.Orange;
        }

        private void rb1Blue_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1Blue.Checked && rb2Blue.Checked)
                this.BackColor = Color.Blue;
            else if (rb1Blue.Checked && rb2Yellow.Checked)
                this.BackColor = Color.Green;
            else if (rb1Red.Checked && rb2Blue.Checked)
                this.BackColor = Color.Purple;
            else
                this.BackColor = Color.Orange;
        }

        private void rb2Blue_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1Blue.Checked && rb2Blue.Checked)
                this.BackColor = Color.Blue;
            else if (rb1Blue.Checked && rb2Yellow.Checked)
                this.BackColor = Color.Green;
            else if (rb1Red.Checked && rb2Blue.Checked)
                this.BackColor = Color.Purple;
            else
                this.BackColor = Color.Orange;
        }

        private void rb2Yellow_CheckedChanged(object sender, EventArgs e)
        {
            if (rb1Blue.Checked && rb2Blue.Checked)
                this.BackColor = Color.Blue;
            else if (rb1Blue.Checked && rb2Yellow.Checked)
                this.BackColor = Color.Green;
            else if (rb1Red.Checked && rb2Blue.Checked)
                this.BackColor = Color.Purple;
            else
                this.BackColor = Color.Orange;
        }
    }
}
